/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hepiment <hepiment@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/19 21:50:18 by hepiment          #+#    #+#             */
/*   Updated: 2022/04/20 15:58:13 by hepiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>
#include<stdio.h>

int	ft_str_is_alpha(char *str)
{
	int i;

	i = 0;
	while(str[i] > 0)
	{
		if (!(str[i] > 64 && str[i] < 91 || str[0] == '\0' || str[i] > 96 && str[i] < 123))
		{
			
			printf("0");
			return (0);
		}
		i++;
	}
	printf("1");
	return (1);
}


int	main(void)
{
	char	str[] = "asssdasdfefefewhrKK1KOWEOEr";
	char	str2[] = "rjelkwrjwelkrjewlkjKKJJWJEIOOQ";
	
	ft_str_is_alpha(str);
	ft_str_is_alpha(str2);
}