/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hepiment <hepiment@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/19 21:50:18 by hepiment          #+#    #+#             */
/*   Updated: 2022/04/20 16:14:37 by hepiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>
#include<stdio.h>

char	*ft_strlowcase(char *str)
{
	int i;
	
	i = 0;
	while(str[i] > 0)
	{
		if (!(str[i] > 96 && str[i] < 123))
		{
			str[i] = str[i] + 32;
		}
		i++;
	}
	return (str);
}


int	main(void)
{
	//char	str[] = {31};
	char	str2[] = "ASrjelkwrjwelkrjewlkjKKJJWJEIOOQ";
	
	//ft_str_is_alpha(str);
	ft_strlowcase(str2);
	printf("%s", str2);
}